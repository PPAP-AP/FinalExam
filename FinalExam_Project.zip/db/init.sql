CREATE TABLE references (
    id SERIAL PRIMARY KEY,
    title TEXT NOT NULL,
    pdf_url TEXT NOT NULL
);